
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useToast } from '@/components/ui/use-toast';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';

const signUpSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Please enter a valid email"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  role: z.enum(["voter", "nominee"])
});

type SignUpFormValues = z.infer<typeof signUpSchema>;

const SignUp = () => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  
  const form = useForm<SignUpFormValues>({
    resolver: zodResolver(signUpSchema),
    defaultValues: {
      name: "",
      email: "",
      password: "",
      role: "voter"
    }
  });

  const onSubmit = async (data: SignUpFormValues) => {
    setIsLoading(true);
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Store user in localStorage for demo purposes
      // In a real app, this would be handled by a backend
      const users = JSON.parse(localStorage.getItem('users') || '[]');
      const existingUser = users.find((user: any) => user.email === data.email);
      
      if (existingUser) {
        toast({
          title: "Account already exists",
          description: "Please log in instead",
          variant: "destructive"
        });
        setIsLoading(false);
        return;
      }
      
      const newUser = {
        id: `user-${Date.now()}`,
        name: data.name,
        email: data.email,
        password: data.password, // In a real app, NEVER store plain text passwords
        role: data.role,
        votingChances: data.role === "nominee" ? 3 : 3, // Nominees and voters both get 3 chances
        hasVoted: false,
        categories: {}
      };
      
      users.push(newUser);
      localStorage.setItem('users', JSON.stringify(users));
      
      // Set the current user
      localStorage.setItem('currentUser', JSON.stringify(newUser));
      
      toast({
        title: "Account created!",
        description: `You've successfully registered as a ${data.role}`,
      });
      
      // If user is a nominee, add them to nominees list
      if (data.role === "nominee") {
        const categories = JSON.parse(localStorage.getItem('categories') || '[]');
        // Use first category for simplicity
        if (categories.length > 0) {
          const categoryId = categories[0].id;
          
          const nominees = JSON.parse(localStorage.getItem('nominees') || '[]');
          nominees.push({
            id: newUser.id,
            name: data.name,
            photoUrl: '/placeholder.svg',
            description: `Nominee: ${data.name}`,
            category: categoryId,
            votes: 1 // Nominees get one automatic vote
          });
          localStorage.setItem('nominees', JSON.stringify(nominees));
        }
      }
      
      // Redirect to voting page
      navigate('/');
    } catch (error) {
      toast({
        title: "Error signing up",
        description: "Something went wrong. Please try again.",
        variant: "destructive"
      });
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-prom-purple/10 to-transparent">
      <div className="w-full max-w-md p-8 bg-white rounded-xl shadow-lg">
        <div className="text-center mb-6">
          <h1 className="text-3xl font-bold text-prom-purple">Join Prom Voting</h1>
          <p className="text-gray-600 mt-2">Create an account to get started</p>
        </div>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Full Name</FormLabel>
                  <FormControl>
                    <Input placeholder="Enter your full name" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Email</FormLabel>
                  <FormControl>
                    <Input type="email" placeholder="your.email@example.com" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="password"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Password</FormLabel>
                  <FormControl>
                    <Input type="password" placeholder="******" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="role"
              render={({ field }) => (
                <FormItem className="space-y-3">
                  <FormLabel>I want to</FormLabel>
                  <FormControl>
                    <RadioGroup
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                      className="flex flex-col space-y-1"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="voter" id="voter" />
                        <FormLabel htmlFor="voter" className="cursor-pointer">Vote for nominees</FormLabel>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="nominee" id="nominee" />
                        <FormLabel htmlFor="nominee" className="cursor-pointer">Be nominated (gets one automatic vote)</FormLabel>
                      </div>
                    </RadioGroup>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <Button 
              type="submit" 
              className="w-full py-6 bg-prom-gold hover:bg-prom-gold/90 text-prom-black font-semibold text-lg rounded-full"
              disabled={isLoading}
            >
              {isLoading ? "Creating account..." : "Sign Up"}
            </Button>
          </form>
        </Form>
        
        <div className="mt-6 text-center">
          <p className="text-sm text-gray-600">
            Already have an account?{" "}
            <button
              onClick={() => navigate("/login")}
              className="text-prom-purple hover:underline font-medium"
            >
              Log in
            </button>
          </p>
        </div>
      </div>
    </div>
  );
};

export default SignUp;
