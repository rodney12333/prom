
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useToast } from '@/components/ui/use-toast';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { UserIcon } from 'lucide-react';

const loginSchema = z.object({
  email: z.string().email("Please enter a valid email"),
  password: z.string().min(1, "Password is required"),
});

type LoginFormValues = z.infer<typeof loginSchema>;

const Login = () => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  
  const form = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: "",
      password: "",
    }
  });

  const onSubmit = async (data: LoginFormValues) => {
    setIsLoading(true);
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Check against localStorage for demo purposes
      // In a real app, this would be handled by a backend
      const users = JSON.parse(localStorage.getItem('users') || '[]');
      const user = users.find((u: any) => 
        u.email === data.email && u.password === data.password
      );
      
      if (!user) {
        toast({
          title: "Login failed",
          description: "Invalid email or password",
          variant: "destructive"
        });
        setIsLoading(false);
        return;
      }
      
      // Set the current user
      localStorage.setItem('currentUser', JSON.stringify(user));
      
      toast({
        title: "Welcome back!",
        description: `You've successfully logged in as ${user.name}`,
      });
      
      // Check if admin and redirect accordingly
      if (user.role === 'admin') {
        navigate('/admin');
      } else {
        navigate('/');
      }
    } catch (error) {
      toast({
        title: "Error logging in",
        description: "Something went wrong. Please try again.",
        variant: "destructive"
      });
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-prom-purple/10 to-transparent">
      <div className="w-full max-w-md p-8 bg-white rounded-xl shadow-lg">
        <div className="text-center mb-6">
          <UserIcon className="h-12 w-12 mx-auto text-prom-purple" />
          <h1 className="text-3xl font-bold text-prom-purple mt-2">Welcome Back</h1>
          <p className="text-gray-600 mt-2">Login to access prom voting</p>
        </div>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Email</FormLabel>
                  <FormControl>
                    <Input type="email" placeholder="your.email@example.com" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="password"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Password</FormLabel>
                  <FormControl>
                    <Input type="password" placeholder="******" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <Button 
              type="submit" 
              className="w-full py-6 bg-prom-purple hover:bg-prom-purple/90 text-white font-semibold text-lg rounded-full"
              disabled={isLoading}
            >
              {isLoading ? "Logging in..." : "Log In"}
            </Button>
          </form>
        </Form>
        
        <div className="mt-6 text-center">
          <p className="text-sm text-gray-600">
            Don't have an account?{" "}
            <button
              onClick={() => navigate("/signup")}
              className="text-prom-purple hover:underline font-medium"
            >
              Sign up
            </button>
          </p>
          <p className="text-xs text-gray-500 mt-4">
            <button
              onClick={() => {
                // Create an admin user if it doesn't exist
                const users = JSON.parse(localStorage.getItem('users') || '[]');
                if (!users.some((u: any) => u.role === 'admin')) {
                  users.push({
                    id: 'admin-1',
                    name: 'Admin User',
                    email: 'admin@example.com',
                    password: 'admin123',
                    role: 'admin'
                  });
                  localStorage.setItem('users', JSON.stringify(users));
                }
                toast({
                  title: "Admin credentials",
                  description: "Email: admin@example.com, Password: admin123",
                });
              }}
              className="text-gray-400 hover:text-gray-600"
            >
              For demo purposes: Get admin credentials
            </button>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;
