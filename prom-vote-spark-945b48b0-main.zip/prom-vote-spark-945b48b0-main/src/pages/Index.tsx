
import React from 'react';
import Hero from '@/components/Hero';
import VotingSection from '@/components/VotingSection';
import { HeartIcon } from 'lucide-react';

const Index = () => {
  return (
    <div className="min-h-screen">
      <Hero />
      <VotingSection />
      
      <footer className="bg-prom-black text-white py-8">
        <div className="container mx-auto px-4 text-center">
          <p className="flex items-center justify-center text-sm">
            Made with <HeartIcon className="h-4 w-4 mx-1 text-prom-gold" /> for the 2024 Prom
          </p>
          <p className="mt-2 text-xs text-gray-500">
            Your votes are secure and anonymous. Results will be announced at the prom night ceremony.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
