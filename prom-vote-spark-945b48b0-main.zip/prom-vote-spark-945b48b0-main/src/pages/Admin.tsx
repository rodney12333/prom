
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { 
  Crown, 
  Users, 
  Award, 
  BarChart, 
  LogOut, 
  Play, 
  Pause, 
  TrophyIcon 
} from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

interface User {
  id: string;
  name: string;
  email: string;
  role: string;
  votingChances: number;
}

interface Nominee {
  id: string;
  name: string;
  photoUrl: string;
  description: string;
  category: string;
  votes: number;
}

interface Category {
  id: string;
  name: string;
  description: string;
}

const Admin = () => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [isVotingEnabled, setIsVotingEnabled] = useState(false);
  const [users, setUsers] = useState<User[]>([]);
  const [nominees, setNominees] = useState<Nominee[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [isReady, setIsReady] = useState(false);
  
  useEffect(() => {
    // Check if user is admin
    const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
    if (currentUser.role !== 'admin') {
      toast({
        title: "Access denied",
        description: "You don't have permission to view this page",
        variant: "destructive"
      });
      navigate('/');
      return;
    }
    
    // Load data
    const storedUsers = JSON.parse(localStorage.getItem('users') || '[]');
    const storedNominees = JSON.parse(localStorage.getItem('nominees') || '[]');
    const storedCategories = JSON.parse(localStorage.getItem('categories') || '[]');
    const votingStatus = localStorage.getItem('votingEnabled') === 'true';
    
    setUsers(storedUsers);
    setNominees(storedNominees);
    setCategories(storedCategories);
    setIsVotingEnabled(votingStatus);
    setIsReady(true);
  }, [navigate, toast]);
  
  const handleToggleVoting = () => {
    const newStatus = !isVotingEnabled;
    setIsVotingEnabled(newStatus);
    localStorage.setItem('votingEnabled', newStatus.toString());
    
    toast({
      title: newStatus ? "Voting enabled" : "Voting disabled",
      description: newStatus ? "Users can now vote" : "Voting has been paused",
    });
  };
  
  const handleLogout = () => {
    localStorage.removeItem('currentUser');
    navigate('/login');
    
    toast({
      title: "Logged out",
      description: "You've been successfully logged out",
    });
  };
  
  if (!isReady) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-prom-purple mx-auto"></div>
          <p className="mt-4 text-prom-purple">Loading admin dashboard...</p>
        </div>
      </div>
    );
  }
  
  // Calculate statistics
  const totalVoters = users.filter(user => user.role === 'voter').length;
  const totalNominees = users.filter(user => user.role === 'nominee').length;
  const totalVotes = nominees.reduce((sum, nominee) => sum + nominee.votes, 0);
  
  // Group nominees by category
  const nomineesByCategory = nominees.reduce((acc, nominee) => {
    if (!acc[nominee.category]) {
      acc[nominee.category] = [];
    }
    acc[nominee.category].push(nominee);
    return acc;
  }, {} as Record<string, Nominee[]>);
  
  // Sort nominees by votes within each category
  Object.keys(nomineesByCategory).forEach(categoryId => {
    nomineesByCategory[categoryId].sort((a, b) => b.votes - a.votes);
  });
  
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-prom-purple text-white p-4 shadow-md">
        <div className="container mx-auto flex justify-between items-center">
          <div className="flex items-center">
            <Crown className="h-8 w-8 mr-2" />
            <h1 className="text-2xl font-bold">Prom Admin Panel</h1>
          </div>
          <div className="flex items-center">
            <Button 
              variant="outline" 
              className="mr-2 text-white border-white hover:bg-white hover:text-prom-purple"
              onClick={handleToggleVoting}
            >
              {isVotingEnabled ? (
                <>
                  <Pause className="mr-2 h-4 w-4" />
                  Pause Voting
                </>
              ) : (
                <>
                  <Play className="mr-2 h-4 w-4" />
                  Start Voting
                </>
              )}
            </Button>
            <Button 
              variant="outline" 
              className="text-white border-white hover:bg-white hover:text-prom-purple"
              onClick={handleLogout}
            >
              <LogOut className="mr-2 h-4 w-4" />
              Logout
            </Button>
          </div>
        </div>
      </div>
      
      <div className="container mx-auto p-4 md:p-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Total Voters</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{totalVoters}</div>
              <p className="text-xs text-muted-foreground mt-1">
                Students voting in the prom awards
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Total Nominees</CardTitle>
              <Award className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{totalNominees}</div>
              <p className="text-xs text-muted-foreground mt-1">
                Students nominated for awards
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Total Votes Cast</CardTitle>
              <BarChart className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{totalVotes}</div>
              <p className="text-xs text-muted-foreground mt-1">
                Across all categories
              </p>
            </CardContent>
          </Card>
        </div>
        
        <Tabs defaultValue="results">
          <TabsList className="mb-6">
            <TabsTrigger value="results">Voting Results</TabsTrigger>
            <TabsTrigger value="users">User Management</TabsTrigger>
          </TabsList>
          
          <TabsContent value="results" className="space-y-8">
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold flex items-center">
                  <TrophyIcon className="h-5 w-5 mr-2 text-prom-gold" />
                  Voting Results by Category
                </h2>
                <div className="text-sm">
                  <span className={`px-2 py-1 rounded-full ${isVotingEnabled ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                    {isVotingEnabled ? 'Voting Open' : 'Voting Closed'}
                  </span>
                </div>
              </div>
              
              {categories.map(category => {
                const categoryNominees = nomineesByCategory[category.id] || [];
                const maxVotes = categoryNominees.length > 0 
                  ? Math.max(...categoryNominees.map(n => n.votes))
                  : 1;
                
                return (
                  <div key={category.id} className="mb-8">
                    <h3 className="text-lg font-medium mb-4">{category.name}</h3>
                    
                    {categoryNominees.length === 0 ? (
                      <p className="text-gray-500 italic">No nominees in this category</p>
                    ) : (
                      <div className="space-y-3">
                        {categoryNominees.map((nominee, index) => {
                          const percentage = Math.round((nominee.votes / maxVotes) * 100);
                          const isLeading = index === 0;
                          
                          return (
                            <div key={nominee.id} className="bg-gray-50 p-4 rounded-lg">
                              <div className="flex items-center justify-between mb-2">
                                <div className="flex items-center">
                                  <div className="mr-3 w-6 text-center font-bold text-gray-400">
                                    {index + 1}
                                  </div>
                                  <span className="font-medium">{nominee.name}</span>
                                  {isLeading && (
                                    <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-prom-gold text-prom-black">
                                      <Crown className="h-3 w-3 mr-1" />
                                      Leading
                                    </span>
                                  )}
                                </div>
                                <span className="font-semibold">{nominee.votes} votes</span>
                              </div>
                              <Progress 
                                value={percentage} 
                                className={`h-2 ${isLeading ? 'bg-gray-200' : 'bg-gray-100'}`}
                              />
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </TabsContent>
          
          <TabsContent value="users">
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h2 className="text-xl font-semibold mb-6">User Management</h2>
              
              <div className="overflow-x-auto">
                <table className="w-full table-auto">
                  <thead>
                    <tr className="bg-gray-50">
                      <th className="px-4 py-2 text-left">Name</th>
                      <th className="px-4 py-2 text-left">Email</th>
                      <th className="px-4 py-2 text-left">Role</th>
                      <th className="px-4 py-2 text-left">Voting Chances Left</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {users.filter(user => user.role !== 'admin').map(user => (
                      <tr key={user.id} className="hover:bg-gray-50">
                        <td className="px-4 py-3">{user.name}</td>
                        <td className="px-4 py-3">{user.email}</td>
                        <td className="px-4 py-3">
                          <span className={`px-2 py-1 text-xs rounded-full ${
                            user.role === 'nominee' 
                              ? 'bg-purple-100 text-purple-800' 
                              : 'bg-blue-100 text-blue-800'
                          }`}>
                            {user.role}
                          </span>
                        </td>
                        <td className="px-4 py-3">{user.votingChances || 0}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              
              {users.filter(user => user.role !== 'admin').length === 0 && (
                <div className="text-center py-8 text-gray-500">
                  No users have registered yet
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default Admin;
