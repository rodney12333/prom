
import React from 'react';
import { Card, CardContent, CardHeader, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Nominee } from '@/data/nominees';
import { Crown, ThumbsUp } from 'lucide-react';
import { cn } from '@/lib/utils';

interface NomineeCardProps {
  nominee: Nominee;
  isSelected: boolean;
  onVote: (nomineeId: string) => void;
  showVotes: boolean;
}

const NomineeCard: React.FC<NomineeCardProps> = ({ 
  nominee, 
  isSelected, 
  onVote,
  showVotes
}) => {
  const totalVotes = showVotes ? nominee.votes : null;
  
  return (
    <Card className={cn(
      "transition-all duration-300 overflow-hidden h-full flex flex-col",
      isSelected ? "card-highlight bg-gradient-to-b from-prom-purple/10 to-transparent border-prom-gold" : ""
    )}>
      <div className="relative aspect-square overflow-hidden">
        <img 
          src={nominee.photoUrl} 
          alt={nominee.name} 
          className="h-full w-full object-cover transition-transform duration-500 hover:scale-105"
        />
        {isSelected && (
          <div className="absolute top-2 right-2">
            <Badge className="bg-prom-gold text-prom-black">
              <Crown className="h-3 w-3 mr-1" />
              Selected
            </Badge>
          </div>
        )}
      </div>
      
      <CardHeader className="p-4 pb-0">
        <h3 className="text-xl font-semibold">{nominee.name}</h3>
      </CardHeader>
      
      <CardContent className="p-4 pt-2 flex-grow">
        <p className="text-sm text-gray-600">{nominee.description}</p>
        
        {showVotes && (
          <div className="mt-2 flex items-center">
            <ThumbsUp className="h-4 w-4 text-prom-purple mr-1" />
            <span className="text-sm font-medium">{totalVotes} votes</span>
          </div>
        )}
      </CardContent>
      
      <CardFooter className="p-4 pt-0">
        <Button 
          className={cn(
            "w-full", 
            isSelected 
              ? "bg-prom-gold text-prom-black hover:bg-prom-gold/90" 
              : "bg-prom-purple hover:bg-prom-purple/90"
          )}
          onClick={() => onVote(nominee.id)}
          disabled={isSelected && showVotes}
        >
          {showVotes 
            ? (isSelected ? 'Your Vote' : 'View Results') 
            : (isSelected ? 'Selected' : 'Vote')}
        </Button>
      </CardFooter>
    </Card>
  );
};

export default NomineeCard;
