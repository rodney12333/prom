
import React from 'react';
import { Button } from '@/components/ui/button';
import { SparklesIcon } from 'lucide-react';

const Hero = () => {
  const scrollToVoting = () => {
    const votingSection = document.getElementById('voting-section');
    if (votingSection) {
      votingSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="hero-pattern relative min-h-[80vh] flex flex-col items-center justify-center px-4 lg:px-8 py-16 overflow-hidden">
      <div className="absolute inset-0 bg-black opacity-50"></div>
      
      {/* Decorative elements */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden">
        <div className="absolute top-[10%] left-[10%] h-1 w-1 bg-prom-gold rounded-full animate-float" style={{ animationDelay: '0.5s' }}></div>
        <div className="absolute top-[20%] left-[80%] h-2 w-2 bg-prom-gold rounded-full animate-float" style={{ animationDelay: '1.5s' }}></div>
        <div className="absolute top-[70%] left-[15%] h-2 w-2 bg-prom-gold rounded-full animate-float" style={{ animationDelay: '1s' }}></div>
        <div className="absolute top-[40%] left-[90%] h-1 w-1 bg-prom-gold rounded-full animate-float" style={{ animationDelay: '0s' }}></div>
        <div className="absolute top-[85%] left-[80%] h-1 w-1 bg-prom-gold rounded-full animate-float" style={{ animationDelay: '2s' }}></div>
      </div>

      <div className="relative z-10 text-center">
        <h1 className="font-bold text-5xl md:text-7xl mb-2 text-white">
          <span className="relative inline-block">
            Prom Night
            <span className="absolute -inset-1 bg-gradient-to-r from-prom-purple/20 to-prom-gold/20 blur-md rounded-lg"></span>
          </span> 
          <span className="gradient-text"> 2024</span>
        </h1>
        
        <div className="w-24 h-1 mx-auto my-6 bg-prom-gold shimmer rounded-full"></div>
        
        <p className="text-white/80 max-w-2xl mx-auto text-xl mb-8 font-light">
          Vote for your favorite nominees and crown this year's prom royalty! Make this magical night even more special by celebrating your classmates.
        </p>
        
        <Button 
          onClick={scrollToVoting}
          className="group relative px-8 py-6 bg-prom-gold hover:bg-prom-gold/90 text-prom-black font-semibold text-lg rounded-full"
        >
          <SparklesIcon className="w-5 h-5 mr-2 inline-block animate-float" />
          Cast Your Vote
          <span className="absolute -inset-0.5 -z-10 rounded-full bg-gradient-to-r from-prom-purple to-prom-gold opacity-30 blur-md group-hover:opacity-60 transition-opacity"></span>
        </Button>
      </div>
    </div>
  );
};

export default Hero;
