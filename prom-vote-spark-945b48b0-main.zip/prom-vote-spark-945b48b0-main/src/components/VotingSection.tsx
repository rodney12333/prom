
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { categories, nominees } from '@/data/nominees';
import CategorySection from './CategorySection';
import { CheckCheck, VoteIcon, AlertTriangle, InfoIcon } from 'lucide-react';
import ResultsSection from './ResultsSection';
import { useNavigate } from 'react-router-dom';

const VotingSection = () => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [selectedNominees, setSelectedNominees] = useState<Record<string, string>>({});
  const [showResults, setShowResults] = useState(false);
  const [localCategories, setLocalCategories] = useState(categories);
  const [localNominees, setLocalNominees] = useState(nominees);
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [isVotingEnabled, setIsVotingEnabled] = useState(false);
  
  useEffect(() => {
    // Check if user is logged in
    const userJson = localStorage.getItem('currentUser');
    if (!userJson) {
      navigate('/login');
      return;
    }
    
    const user = JSON.parse(userJson);
    setCurrentUser(user);
    
    // Load data from localStorage
    const storedCategories = JSON.parse(localStorage.getItem('categories') || 'null');
    const storedNominees = JSON.parse(localStorage.getItem('nominees') || 'null');
    const votingStatus = localStorage.getItem('votingEnabled') === 'true';
    
    // Initialize localStorage if empty
    if (!storedCategories) {
      localStorage.setItem('categories', JSON.stringify(categories));
    } else {
      setLocalCategories(storedCategories);
    }
    
    if (!storedNominees) {
      localStorage.setItem('nominees', JSON.stringify(nominees));
    } else {
      setLocalNominees(storedNominees);
    }
    
    setIsVotingEnabled(votingStatus);
    
    // Load user's previous votes if any
    if (user.categories) {
      setSelectedNominees(user.categories);
    }
  }, [navigate]);
  
  const handleVote = (nomineeId: string) => {
    // If voting is disabled, show message
    if (!isVotingEnabled) {
      toast({
        title: "Voting is currently closed",
        description: "The admin has not started the voting period yet.",
        variant: "default"
      });
      return;
    }
    
    // Check if user has votes left
    if (currentUser?.votingChances <= 0) {
      toast({
        title: "No voting chances left",
        description: "You've used all your voting opportunities.",
        variant: "destructive"
      });
      return;
    }
    
    const nominee = localNominees.find(n => n.id === nomineeId);
    if (!nominee) return;
    
    setSelectedNominees(prev => {
      // If already selected, deselect it
      if (prev[nominee.category] === nomineeId) {
        const newSelections = { ...prev };
        delete newSelections[nominee.category];
        return newSelections;
      }
      
      // Otherwise select it
      return { ...prev, [nominee.category]: nomineeId };
    });
  };
  
  const handleSubmitVotes = () => {
    if (!currentUser) return;
    
    const categoryCount = localCategories.length;
    const voteCount = Object.keys(selectedNominees).length;
    
    if (voteCount < categoryCount) {
      toast({
        title: "Almost there!",
        description: `You've voted in ${voteCount} out of ${categoryCount} categories. Complete all categories to submit.`,
        variant: "default"
      });
      return;
    }
    
    // Update nominees with votes
    const updatedNominees = [...localNominees];
    Object.values(selectedNominees).forEach(nomineeId => {
      const nomineeIndex = updatedNominees.findIndex(n => n.id === nomineeId);
      if (nomineeIndex >= 0) {
        updatedNominees[nomineeIndex].votes += 1;
      }
    });
    
    // Update localStorage
    localStorage.setItem('nominees', JSON.stringify(updatedNominees));
    setLocalNominees(updatedNominees);
    
    // Update user
    const updatedUser = {
      ...currentUser,
      votingChances: currentUser.votingChances - 1,
      hasVoted: true,
      categories: selectedNominees
    };
    localStorage.setItem('currentUser', JSON.stringify(updatedUser));
    setCurrentUser(updatedUser);
    
    // Update users array
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const userIndex = users.findIndex((u: any) => u.id === currentUser.id);
    if (userIndex >= 0) {
      users[userIndex] = updatedUser;
      localStorage.setItem('users', JSON.stringify(users));
    }
    
    setShowResults(true);
    
    toast({
      title: "Votes submitted!",
      description: `Thank you for voting! You have ${updatedUser.votingChances} voting chances left.`,
      variant: "default"
    });
  };
  
  const resetVotes = () => {
    setSelectedNominees({});
    setShowResults(false);
  };
  
  const handleLogout = () => {
    localStorage.removeItem('currentUser');
    navigate('/login');
  };
  
  if (!currentUser) {
    return (
      <div className="flex justify-center items-center h-96">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-prom-purple mx-auto"></div>
          <p className="mt-4 text-prom-purple">Loading...</p>
        </div>
      </div>
    );
  }
  
  return (
    <div id="voting-section" className="container mx-auto px-4 py-12">
      <div className="flex justify-between items-center mb-8">
        <div>
          <div className="text-sm text-gray-500 mb-1">Logged in as</div>
          <div className="font-medium">{currentUser.name} ({currentUser.role})</div>
          <div className="text-sm text-gray-500 mt-1">
            Voting chances left: <span className="font-medium">{currentUser.votingChances}</span>
          </div>
        </div>
        <div>
          <Button 
            variant="outline" 
            onClick={handleLogout}
            className="mr-2"
          >
            Logout
          </Button>
          {currentUser.role === 'admin' && (
            <Button
              onClick={() => navigate('/admin')}
              className="bg-prom-purple hover:bg-prom-purple/90"
            >
              Admin Panel
            </Button>
          )}
        </div>
      </div>
      
      {!isVotingEnabled && (
        <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 mb-8">
          <div className="flex">
            <div className="flex-shrink-0">
              <AlertTriangle className="h-5 w-5 text-yellow-400" />
            </div>
            <div className="ml-3">
              <p className="text-sm text-yellow-700">
                Voting is currently closed. Please wait for the admin to start the voting period.
              </p>
            </div>
          </div>
        </div>
      )}
      
      {currentUser.votingChances <= 0 && (
        <div className="bg-blue-50 border-l-4 border-blue-400 p-4 mb-8">
          <div className="flex">
            <div className="flex-shrink-0">
              <InfoIcon className="h-5 w-5 text-blue-400" />
            </div>
            <div className="ml-3">
              <p className="text-sm text-blue-700">
                You have used all your voting chances. You can still view the results but cannot vote anymore.
              </p>
            </div>
          </div>
        </div>
      )}
      
      <div className="text-center mb-12">
        <h2 className="text-4xl md:text-5xl font-bold mb-4">Cast Your Vote</h2>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          {showResults 
            ? "Results are in! See who's leading in each category." 
            : "Select one nominee from each category to cast your votes for this year's prom awards!"}
        </p>
      </div>
      
      {localCategories.map(category => {
        const categoryNominees = localNominees.filter(n => n.category === category.id);
        return (
          <CategorySection 
            key={category.id}
            category={category}
            nominees={categoryNominees}
            selectedNomineeId={selectedNominees[category.id] || null}
            onVote={handleVote}
            showResults={showResults}
          />
        );
      })}
      
      {showResults && <ResultsSection nominees={localNominees} selections={selectedNominees} />}
      
      <div className="flex justify-center mt-12">
        {!showResults ? (
          <Button 
            className="px-8 py-6 bg-prom-gold hover:bg-prom-gold/90 text-prom-black font-semibold text-lg rounded-full"
            onClick={handleSubmitVotes}
            disabled={!isVotingEnabled || currentUser.votingChances <= 0}
          >
            <VoteIcon className="w-5 h-5 mr-2" />
            Submit Votes
          </Button>
        ) : (
          <Button 
            className="px-8 py-6 bg-prom-purple hover:bg-prom-purple/90 text-white font-semibold text-lg rounded-full"
            onClick={resetVotes}
            disabled={!isVotingEnabled || currentUser.votingChances <= 0}
          >
            <CheckCheck className="w-5 h-5 mr-2" />
            Vote Again
          </Button>
        )}
      </div>
    </div>
  );
};

export default VotingSection;
