
import React from 'react';
import { Progress } from '@/components/ui/progress';
import { Nominee } from '@/data/nominees';
import { Crown, TrophyIcon } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ResultsSectionProps {
  nominees: Nominee[];
  selections: Record<string, string>;
}

const ResultsSection: React.FC<ResultsSectionProps> = ({ nominees, selections }) => {
  // Group nominees by category and find the winner in each category
  const categorizedResults = nominees.reduce((acc, nominee) => {
    if (!acc[nominee.category]) {
      acc[nominee.category] = [];
    }
    acc[nominee.category].push(nominee);
    return acc;
  }, {} as Record<string, Nominee[]>);
  
  // Sort nominees by votes within each category
  Object.keys(categorizedResults).forEach(categoryId => {
    categorizedResults[categoryId].sort((a, b) => b.votes - a.votes);
  });
  
  // Find max votes in each category for percentage calculation
  const maxVotesByCategory = Object.keys(categorizedResults).reduce((acc, categoryId) => {
    const maxVotes = Math.max(...categorizedResults[categoryId].map(n => n.votes));
    return { ...acc, [categoryId]: maxVotes > 0 ? maxVotes : 1 };
  }, {} as Record<string, number>);
  
  return (
    <div className="mt-16 mb-12 bg-gradient-to-b from-prom-purple/5 to-transparent p-8 rounded-2xl">
      <div className="text-center mb-8">
        <TrophyIcon className="w-12 h-12 text-prom-gold mx-auto mb-4" />
        <h2 className="text-3xl md:text-4xl font-bold text-prom-purple mb-2">Results</h2>
        <p className="text-gray-600">See who's leading in each category</p>
      </div>
      
      <div className="space-y-12">
        {Object.keys(categorizedResults).map(categoryId => {
          const categoryNominees = categorizedResults[categoryId];
          const maxVotes = maxVotesByCategory[categoryId];
          
          return (
            <div key={categoryId} className="space-y-4">
              <h3 className="text-2xl font-semibold">{categoryNominees[0]?.category.replace(/-/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}</h3>
              
              <div className="space-y-3">
                {categoryNominees.map((nominee, index) => {
                  const isWinner = index === 0;
                  const isSelected = selections[categoryId] === nominee.id;
                  const percentage = Math.round((nominee.votes / maxVotes) * 100);
                  
                  return (
                    <div key={nominee.id} className="bg-white p-4 rounded-lg shadow-sm">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center">
                          <div className="mr-3 w-6 text-center font-bold text-gray-400">
                            {index + 1}
                          </div>
                          <span className="font-medium">{nominee.name}</span>
                          {isSelected && (
                            <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-prom-purple text-white">
                              Your Vote
                            </span>
                          )}
                          {isWinner && (
                            <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-prom-gold text-prom-black">
                              <Crown className="h-3 w-3 mr-1" />
                              Leading
                            </span>
                          )}
                        </div>
                        <span className="font-semibold">{nominee.votes} votes</span>
                      </div>
                      <Progress 
                        value={percentage} 
                        className={cn(
                          "h-2", 
                          isWinner ? "bg-gray-200" : "bg-gray-100"
                        )}
                        style={{
                          "--progress-background": isWinner 
                            ? "var(--prom-gold)" 
                            : isSelected 
                              ? "var(--prom-purple)" 
                              : "#9ca3af"
                        } as React.CSSProperties}
                      />
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default ResultsSection;
