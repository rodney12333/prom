
import React from 'react';
import { Nominee, Category } from '@/data/nominees';
import NomineeCard from './NomineeCard';

interface CategorySectionProps {
  category: Category;
  nominees: Nominee[];
  selectedNomineeId: string | null;
  onVote: (nomineeId: string) => void;
  showResults: boolean;
}

const CategorySection: React.FC<CategorySectionProps> = ({
  category,
  nominees,
  selectedNomineeId,
  onVote,
  showResults
}) => {
  return (
    <div className="my-12">
      <div className="text-center mb-8">
        <h2 className="text-3xl md:text-4xl font-bold text-prom-purple mb-2">{category.name}</h2>
        <p className="text-gray-600 max-w-2xl mx-auto">{category.description}</p>
        <div className="w-20 h-1 mx-auto mt-4 bg-prom-gold/50 rounded-full"></div>
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {nominees.map(nominee => (
          <NomineeCard 
            key={nominee.id}
            nominee={nominee}
            isSelected={nominee.id === selectedNomineeId}
            onVote={onVote}
            showVotes={showResults}
          />
        ))}
      </div>
    </div>
  );
};

export default CategorySection;
