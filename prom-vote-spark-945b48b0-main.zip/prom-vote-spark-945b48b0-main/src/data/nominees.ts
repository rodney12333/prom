
export interface Nominee {
  id: string;
  name: string;
  photoUrl: string;
  description: string;
  category: string;
  votes: number;
}

export interface Category {
  id: string;
  name: string;
  description: string;
}

export const categories: Category[] = [
  {
    id: 'prom-royalty',
    name: 'Prom Royalty',
    description: 'Vote for the King and Queen of this year\'s prom!'
  },
  {
    id: 'best-dressed',
    name: 'Best Dressed',
    description: 'Who had the most stunning outfit of the night?'
  },
  {
    id: 'best-dancer',
    name: 'Best Dancer',
    description: 'Who owned the dance floor all night long?'
  },
  {
    id: 'cutest-couple',
    name: 'Cutest Couple',
    description: 'Vote for the couple that melts everyone\'s hearts'
  }
];

export const nominees: Nominee[] = [
  // Prom Royalty Nominees
  {
    id: 'royalty-1',
    name: 'Emma Johnson',
    photoUrl: '/placeholder.svg',
    description: 'Senior Class President & Volleyball Captain',
    category: 'prom-royalty',
    votes: 24
  },
  {
    id: 'royalty-2',
    name: 'Michael Chen',
    photoUrl: '/placeholder.svg',
    description: 'Debate Team President & Math Club Leader',
    category: 'prom-royalty',
    votes: 18
  },
  {
    id: 'royalty-3',
    name: 'Sophia Rodriguez',
    photoUrl: '/placeholder.svg',
    description: 'Drama Club Lead & Student Council Secretary',
    category: 'prom-royalty',
    votes: 32
  },
  {
    id: 'royalty-4',
    name: 'James Wilson',
    photoUrl: '/placeholder.svg',
    description: 'Football Team Captain & Honor Society Member',
    category: 'prom-royalty',
    votes: 27
  },
  
  // Best Dressed Nominees
  {
    id: 'dressed-1',
    name: 'Olivia Parker',
    photoUrl: '/placeholder.svg',
    description: 'Fashion Club President with stunning gown',
    category: 'best-dressed',
    votes: 15
  },
  {
    id: 'dressed-2',
    name: 'Ethan Williams',
    photoUrl: '/placeholder.svg',
    description: 'Classic tuxedo with a modern twist',
    category: 'best-dressed',
    votes: 12
  },
  {
    id: 'dressed-3',
    name: 'Ava Thompson',
    photoUrl: '/placeholder.svg',
    description: 'Vintage inspired dress that wowed everyone',
    category: 'best-dressed',
    votes: 19
  },
  {
    id: 'dressed-4',
    name: 'Noah Garcia',
    photoUrl: '/placeholder.svg',
    description: 'Unique cultural formal wear that stood out',
    category: 'best-dressed',
    votes: 16
  },
  
  // Best Dancer Nominees
  {
    id: 'dancer-1',
    name: 'Isabella Martinez',
    photoUrl: '/placeholder.svg',
    description: 'Dance team captain with amazing moves',
    category: 'best-dancer',
    votes: 28
  },
  {
    id: 'dancer-2',
    name: 'William Davis',
    photoUrl: '/placeholder.svg',
    description: 'Breakdancer who surprised everyone',
    category: 'best-dancer',
    votes: 22
  },
  {
    id: 'dancer-3',
    name: 'Mia Jackson',
    photoUrl: '/placeholder.svg',
    description: 'Ballet dancer who owned the floor',
    category: 'best-dancer',
    votes: 20
  },
  {
    id: 'dancer-4',
    name: 'Liam Brown',
    photoUrl: '/placeholder.svg',
    description: 'Self-taught dancer with incredible rhythm',
    category: 'best-dancer',
    votes: 25
  },
  
  // Cutest Couple Nominees
  {
    id: 'couple-1',
    name: 'Charlotte & Benjamin',
    photoUrl: '/placeholder.svg',
    description: 'Dating since freshman year',
    category: 'cutest-couple',
    votes: 31
  },
  {
    id: 'couple-2',
    name: 'Amelia & Henry',
    photoUrl: '/placeholder.svg',
    description: 'Best friends who became a couple',
    category: 'cutest-couple',
    votes: 29
  },
  {
    id: 'couple-3',
    name: 'Evelyn & Alexander',
    photoUrl: '/placeholder.svg',
    description: 'The couple that everyone admires',
    category: 'cutest-couple',
    votes: 35
  },
  {
    id: 'couple-4',
    name: 'Harper & Sebastian',
    photoUrl: '/placeholder.svg',
    description: 'Most supportive couple on campus',
    category: 'cutest-couple',
    votes: 27
  }
];
